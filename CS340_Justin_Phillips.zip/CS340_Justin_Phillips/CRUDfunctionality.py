from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib

class CRUDoperations(object):
    """ CRUD OPERATIONS FOR COLLECTIONS IN MONGODB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This
        # allows for accessing MongoDB databases
        # and collections. This is hardwired to
        # use the aac database, animals 
        # collection, and aacuser account. 
        # 
        # Connection variables:
        #
        USER=urllib.parse.quote_plus(username)
        PASS=urllib.parse.quote_plus(password)
        PORT=32545
        HOST=urllib.parse.quote_plus('nv-desktop-services.apporto.com')
        DB = 'AAC'
        COL = 'animals'
        
        
        # Initialize the connection for the collection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/')
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
        # Print the connection status
        print("Connected to database: ", self.database)
        print("Using collection: ", self.collection)
        print(self.database.command("connectionStatus")["authInfo"]["authenticatedUsers"])
        

        
    # Create
    def create(self, data):
        #if there is data, insert it, if not, throw an exception
        if data is not None:
            self.collection.insert_one(data) # data should be a dict
            return True # There was something to insert and it was inserted
        else:
            raise Exception("Nothing saved. Data parameter empty.")
            return False


    # Read
    def read(self, query):
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except:
            raise Exception("Could not return query")
            return []
        
    # Update
    def update(self, query, new_data):
        try:
            result = self.collection.update_many(query, {'$set': new_data})
            return result.modified_count
        except:
            raise Exception("Update failed.")
            return 0
        
    # Delete
    def delete(self, query):
        try: 
            result = self.collection.delete_many(query)
            return result.deleted_count
        except:
            raise Exception("Deletion failed.")
            return 0
        
